import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { api } from 'src/environments/environment';
import { Teams } from '../models/Teams';

@Injectable({
  providedIn: 'root'
})

export class DataService {
  selectedTeam = [];
  constructor(private http: HttpClient) { }

  // signinApiService(formData): Observable<User> {
  //   console.log(formData);
  //   return this.http.post<User>(api.signin, formData);
  // }

  setSelectedTeam(team_name): void {
    this.selectedTeam.push(team_name);
  }
  getSelectedTeam() {
    return this.selectedTeam;
  }
  getTeamsApiService(): Observable<Teams> {
    return this.http.get<Teams>(api.getTeams);
  }
  storeTeamsApiService(requestBody: any): Observable<any> {
    return this.http.post<any>(api.addTeams, requestBody);
  }
  saveResult(requestBody: { type: string, team_name: string }): Observable<any> {
    return this.http.post<any>(api.changeResult, requestBody);
  }
}
