import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import * as XLSX from 'xlsx';
import { Teams } from '../models/Teams';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {
  formData: FormGroup;
  fileContent: any;
  file: File;
  static requestData: any;
  arrayBuffer: any;
  responseMessage: string;
  constructor(private dataService: DataService) { }

  ngOnInit() {
    this.formData = new FormGroup({
      team_name: new FormControl(null, [Validators.required]),
      wins: new FormControl(null, Validators.required),
      lose: new FormControl(null, Validators.required),
      ties: new FormControl(null, Validators.required),
      score: new FormControl(null, Validators.required),
    })
  }
  fileUpload(event): void {
    console.log('dkjskd');
    this.file = event.target.files[0];
    let fileReader = new FileReader();
    fileReader.readAsArrayBuffer(this.file);
    fileReader.onload = (e) => {
      this.arrayBuffer = fileReader.result;
      var data = new Uint8Array(this.arrayBuffer);
      var arr = new Array();
      for (var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
      var bstr = arr.join("");
      var workbook = XLSX.read(bstr, { type: "binary" });
      //console.log(workbook)  
      var first_sheet_name = workbook.SheetNames[0];
      var worksheet = workbook.Sheets[first_sheet_name];
      //console.log(worksheet)
      var fileContnt: any;
      //fileContnt = XLSX.utils.sheet_to_json(worksheet,{raw:true});

      fileContnt = XLSX.utils.sheet_to_json(workbook.Sheets[first_sheet_name], {
        header: 1,
        defval: '',
        blankrows: true
      });

      console.log(fileContnt);
      let teamdata = {};
      let requestData = {
        teams: []
      };
      for (var j = 0; j < fileContnt.length; j++) {
        teamdata = {};
        teamdata['team_name'] = fileContnt[j][0].trim();
        teamdata['wins'] = fileContnt[j][1];
        teamdata['lose'] = fileContnt[j][2];
        teamdata['ties'] = fileContnt[j][3];
        teamdata['score'] = fileContnt[j][4];
        requestData.teams.push(teamdata)
      }
      this.dataService.storeTeamsApiService(requestData).subscribe(data => {
        this.responseMessage = data.message;
        console.log(data);
      })
    }
  }
  submit() {
    console.log(this.formData);
    this.dataService.storeTeamsApiService({ teams: this.formData.value }).subscribe(data => {
      this.responseMessage = data.message;
    })
  }
}
