import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { DataService } from '../services/data.service';
import * as $ from 'jquery';
@Component({
  selector: 'app-dialoge',
  templateUrl: './dialoge.component.html',
  styleUrls: ['./dialoge.component.scss']
})
export class DialogeComponent implements OnInit {
  teams = [];
  selectTeam: string;
  type: string;
  @Output() event = new EventEmitter();

  constructor(private dataService: DataService) { }

  ngOnInit() {
    this.teams = this.dataService.getSelectedTeam();
    $(document).on('click', 'input[type="checkbox"]', function() {
      $('input[type="checkbox"]').not(this).prop('checked', false);

    });
    $(document).on('click', 'input[type="radio"]', function() {
      $('input[type="radio"]').not(this).prop('checked', false);
    });
  }

  check(event) {
    this.selectTeam = event.target.value;
  }
  radio(event) {
    this.type = event.target.value
  }
  submit() {
    this.dataService.saveResult({ team_name: this.selectTeam, type: this.type }).subscribe(data => {
      this.event.emit('success  ')
    })
  }

}
