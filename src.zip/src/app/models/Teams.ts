export interface Teams {
    team_name: string,
    wins: number,
    losses: number,
    ties: number,
    score: number
}