import { Component, OnInit, ViewChild } from '@angular/core';
import { DataService } from '../services/data.service';
import { Teams } from '../models/Teams'
import { PageEvent } from '@angular/material/paginator';
import { Router } from '@angular/router';
import { Sort } from '@angular/material/sort';
import { fromEvent, Observable } from 'rxjs';
import { filter, debounceTime, distinctUntilChanged, switchMap, tap } from "rxjs/operators";
import { MatDialog } from '@angular/material/dialog';
import { DialogeComponent } from '../dialoge/dialoge.component';

@Component({
  selector: 'app-leaderboard',
  templateUrl: './leaderboard.component.html',
  styleUrls: ['./leaderboard.component.scss']
})
export class LeaderboardComponent implements OnInit {
  teams: Teams[];
  teamSlice: Teams[];
  searchText: string;
  temp: Teams[];
  teamSelectCount = 0;
  showTable = true;
  constructor(private dataService: DataService, private route: Router, public dialog: MatDialog) { }

  ngOnInit() {
    this.dataService.getTeamsApiService().subscribe((responseData: Teams) => {
      this.teams = responseData['teams'];
      this.teamSlice = this.teams.slice(0, 50);
      this.temp = this.teamSlice;
    }, error => {
      console.log(error);
    })
  }

  ngAfterViewInit() {
    let searchBox = document.getElementById("txtSearch");
    fromEvent(searchBox, "input")
      .pipe(
        tap(() => console.log('*')),
        filter(() => this.searchText.length > 0),
        debounceTime(1000),
        distinctUntilChanged(),
        switchMap(() => this.filter(this.teamSlice, this.searchText))).subscribe((response) => { });


  }

  filter(data, text) {
    if (!data) {
      return [-1];
    }
    if (!text) {
      return data;
    }
    text = text.toLowerCase();
    data = data.filter(value => {
      return JSON.stringify(value.team_name).toLocaleLowerCase().includes(text.toString()) || value.score === parseInt(text)
    });
    this.teamSlice = data;
    return data
  }

  OnPageChange(event: PageEvent) {
    const startIndex = event.pageIndex * event.pageSize;
    let endIndex = startIndex + event.pageSize;
    if (endIndex > this.teams.length) {
      endIndex = this.teams.length;
    }
    this.teamSlice = this.teams.slice(startIndex, endIndex);
    this.temp = this.teamSlice;
  }

  openForm() {
    this.route.navigateByUrl('/addTeam');
  }

  sortData(sort: Sort) {
    const data = this.teamSlice.slice();
    console.log(data);
    if (!sort.active || sort.direction === '') {
      this.teamSlice = data;
      return;
    }
    console.log(sort.active);
    this.teamSlice = data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'team_name': return this.compare(a.team_name, b.team_name, isAsc);
        case 'score': return this.compare(a.score, b.score, isAsc);
        default: return 0;
      }
    })
  }
  compare(a: number | string, b: number | string, isAsc: boolean) {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
  }

  selectTeam(event) {
    if (this.teamSelectCount < 2) {
      this.dataService.setSelectedTeam(event.target.value);
      this.teamSelectCount++;
    }
    this.showTable = this.teamSelectCount == 2 ? false : true;
    console.log(event);
  }
}
